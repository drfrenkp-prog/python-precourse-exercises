# Exercise: Dictionary Exercises (all using dictionary comprehension)

# 1. Given a list of (key, value) tuples, create a dictionary.
pairs = [("name", "Elie"), ("job", "Instructor")]
print({k: v for k, v in pairs})
# {'name': 'Elie', 'job': 'Instructor'}

# 2. Given two lists, zip them together into a dictionary.
states = ["CA", "NJ", "RI"]
full_names = ["California", "New Jersey", "Rhode Island"]
print({k: v for k, v in zip(states, full_names)})
# {'CA': 'California', 'NJ': 'New Jersey', 'RI': 'Rhode Island'}

# 3. Create a dictionary with vowels as keys and 0 as the value.
vowels = "aeiou"
print({letter: 0 for letter in vowels})
# {'a': 0, 'e': 0, 'i': 0, 'o': 0, 'u': 0}

# 4. Create a dictionary mapping position (1-26) to the corresponding letter.
print({num: chr(num + 64) for num in range(1, 27)})
# {1: 'A', 2: 'B', ..., 26: 'Z'}

# 5. Super Bonus: given a sentence, count occurrences of each vowel.
sentence = "awesome sauce"
vowels = "aeiou"
print({letter: sentence.count(letter) for letter in vowels})
# {'a': 2, 'e': 3, 'i': 0, 'o': 1, 'u': 1}
