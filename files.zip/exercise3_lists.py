# Exercise: List #1 (all using list comprehension)

# 1. Given [1,2,3,4], print out all the values in the list.
numbers = [1, 2, 3, 4]
print([num for num in numbers])  # [1, 2, 3, 4]

# 2. Given [1,2,3,4], print out all the values multiplied by 20.
print([num * 20 for num in numbers])  # [20, 40, 60, 80]

# 3. Given ["Elie", "Tim", "Matt"], return only the first letter of each.
names = ["Elie", "Tim", "Matt"]
print([name[0] for name in names])  # ['E', 'T', 'M']

# 4. Given [1,2,3,4,5,6], return a new list of all the even values.
numbers = [1, 2, 3, 4, 5, 6]
print([num for num in numbers if num % 2 == 0])  # [2, 4, 6]

# 5. Given two lists, return their intersection.
list1 = [1, 2, 3, 4]
list2 = [3, 4, 5, 6]
print([num for num in list1 if num in list2])  # [3, 4]

# 6. Given ["Elie", "Tim", "Matt"], return each word reversed and lowercase.
print([name.lower()[::-1] for name in names])  # ['eile', 'mit', 'ttam']

# 7. Given two strings, return the letters present in both.
word1 = "first"
word2 = "third"
print([letters for letters in word1 if letters in word2])  # ['i', 'r', 't']

# 8. Numbers between 1 and 100 divisible by 12.
print([num for num in range(1, 101) if num % 12 == 0])
# [12, 24, 36, 48, 60, 72, 84, 96]

# 9. Given "amazing", return a list with all vowels removed.
print([letter for letter in "amazing" if letter not in ['a', 'e', 'i', 'o', 'u']])
# ['m', 'z', 'n', 'g']

# 10. Generate [[0, 1, 2], [0, 1, 2], [0, 1, 2]]
print([[num for num in range(3)] for num_ in range(3)])

# 11. Generate a 10x10 nested list of [0-9]
print([[num for num in range(10)] for num_ in range(10)])
