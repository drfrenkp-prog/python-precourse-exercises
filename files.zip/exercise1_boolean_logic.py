# Exercise 1: Boolean Logic

# 1. Declare a variable called `first` and assign it to "Hello World"
first = "Hello World"

# 2. Comment
# this is a comment

# 3. Print a message
print("I'm a computer")

# 4. If statement checking 1 < 2 and 4 > 2
if 1 < 2 and 4 > 2:
    print("Math is fun.")

# 5. Absence of value
nope = None

# 6. Combine True and False with "and"
print(True and False)  # False

# 7. Length of a string
print(len("What's My Lenght"))  # 16

# 8. Convert to uppercase
string = "i'm shouting"
print(string.upper())  # "I'M SHOUTING"

# 9. Convert "1000" to the number 1000
print(int("1000"))  # 1000

# 10. Combine 4 with "real" to get "4real"
print(str(4) + "real")  # '4real'

# 11. Output of 3 * "cool"
print(3 * "cool")  # 'coolcoolcool'

# 12. Output of 1 / 0
# 1/0  -> ZeroDivisionError: division by zero

# 13. Type of []
print(type([]))  # <class 'list'>

# 14. Ask the user for their name
name = input("What's your name? ")

# 15. Ask for a number, check negative/positive/zero
number = int(input("Enter a number: "))

if number < 0:
    print("That number is less than 0!")
elif number > 0:
    print("That number is greater than 0!")
else:
    print("You picked 0!")
