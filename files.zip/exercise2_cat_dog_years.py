# Exercise 2: Cat's and Dog's Years

def cat_dog_years(human_years):
    if human_years == 1:
        cat_years = 15
        dog_years = 15
    elif human_years == 2:
        cat_years = 24
        dog_years = 24
    else:
        cat_years = 15 + 9 + 4 * (human_years - 2)
        dog_years = 15 + 9 + 5 * (human_years - 2)

    return [human_years, cat_years, dog_years]


print(cat_dog_years(10))  # [10, 56, 64]
print(cat_dog_years(1))   # [1, 15, 15]
print(cat_dog_years(2))   # [2, 24, 24]
